import threading
import time


class AMQPConnectionKeeper(threading.Thread):
    def __init__(self, connection):
        super(self.__class__, self).__init__()
        self.name = "ConnectionKeeperThread"
        self.running = True
        self.interval = 30
        self.connection = connection
        self.state = "STOPPED"

    def shutdown(self):
        self.running = False
        self.state = "STOPPING"

    def run(self) -> None:
        self.state = "STARTED"
        current = 0
        while self.running:
            if int(time.time()) - current > self.interval:
                current = int(time.time())
                try:
                    if self.connection and self.connection.is_open:
                        self.connection.process_data_events()
                except BaseException:
                    pass
            try:
                time.sleep(1)
            except BaseException:
                self.running = False
                break
        self.state = "STOPPED"
