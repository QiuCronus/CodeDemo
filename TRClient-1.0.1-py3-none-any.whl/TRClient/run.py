import sys
import os

from .utils import DataUtils
from .app import start_app
from .version import version


def main():
    main_pid = os.getpid()
    print(f"TRClient v{version}, PID: {main_pid}")

    cwd = os.getcwd()
    sys.path.append(cwd)

    for dir_name in ("plugins", "configs", "logs", "data"):
        DataUtils.ensure_path(os.path.join(cwd, dir_name))

    kwargs = {}
    for arg in sys.argv:
        if arg.startswith("--") and "=" in arg:
            arg = arg.replace("--", "")
            key, value = arg.split("=", 1)
            kwargs[key] = value

    start_app(**kwargs)


if __name__ == "__main__":
    main()
