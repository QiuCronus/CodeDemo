from importlib import import_module
import base64
import ctypes
import hashlib
import json
import logging
import os
import platform
import socket
import shutil
import time
import zlib
import bisect
import uuid
import math
import yaml
import datetime
from logging.handlers import TimedRotatingFileHandler

from Crypto.Cipher import AES


FMT = "[%(levelname).1s] %(asctime)s - %(module)s[%(lineno)d] : %(message)s"
DATEFMT = "%Y/%m/%d %H:%M:%S"


class ConfigUtils:
    @staticmethod
    def load_yml_config(path):
        config = {}
        with open(path, "r") as fd:
            config = yaml.load(fd, Loader=yaml.FullLoader)

        for name, values in config.items():
            if name in ("MQ", "MYSQL", "MONGO"):
                for key in config[name].keys():
                    config[name][key] = CryptoUtils.decrypt_data(config[name][key])

        return config


class TimeUtils:

    @staticmethod
    def utc_timestamp():
        return datetime.datetime.utcnow()

    @staticmethod
    def strtime(formatter="%Y-%m-%d %H:%M:%S"):
        return time.strftime(formatter, time.localtime(time.time()))

    @staticmethod
    def timestamp(length: int = 10):
        bit = length - 10 if length > 10 else 0
        times = math.pow(10, bit)
        return int(time.time() * times)

    @staticmethod
    def yesterday_date():
        today = datetime.date.today()
        delta = datetime.timedelta(days=1)
        return str(today - delta)

    @staticmethod
    def datetime():
        return datetime.datetime.now()


class DataUtils:
    @staticmethod
    def load_object(path):
        try:
            dot = path.rindex(".")
        except ValueError:
            raise ValueError("Error loading object '%s': not a full path" % path)
        module, name = path[:dot], path[dot + 1 :]
        mod = import_module(module)
        try:
            obj = getattr(mod, name)
        except AttributeError:
            raise NameError(
                "Module '%s' doesn't define any object named '%s'" % (module, name)
            )
        return obj

    @staticmethod
    def get_value(data: dict, key: str, default=None):
        if key in data.keys():
            return data[key]
        return default

    @staticmethod
    def generateUID():
        return uuid.uuid4().hex

    @staticmethod
    def ensure_path(path):
        if not os.path.exists(path):
            os.makedirs(path)
        return path

    @staticmethod
    def get_local_ip():
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(("8.8.8.8", 80))
            return s.getsockname()[0]
        except:
            return None
        finally:
            s.close()

    @staticmethod
    def get_free_disk():
        total, uses, free = shutil.disk_usage("/")
        return free

    @staticmethod
    def format_size(size: int):
        d = [
            (1024 - 1, "K"),
            (1024 ** 2 - 1, "M"),
            (1024 ** 3 - 1, "G"),
            (1024 ** 4 - 1, "T"),
        ]
        s = [x[0] for x in d]
        index = bisect.bisect_left(s, size) - 1
        if index == -1:
            return str(size)
        b, u = d[index]
        return str(size / (b + 1)) + u

    @staticmethod
    def str2bytes(data: str):
        try:
            return data.encode("UTF-8")
        except:
            return None

    @staticmethod
    def bytes2str(data: bytes):
        try:
            return data.decode("UTF-8")
        except:
            return None

    @staticmethod
    def b64encode(data):
        bdata = DataUtils.str2bytes(data) if isinstance(data, str) else data
        try:
            return base64.b64encode(bdata).decode()
        except:
            return None

    @staticmethod
    def b64decode(data, return_str=True):
        bdata = DataUtils.str2bytes(data) if isinstance(data, str) else data
        try:
            r = base64.b64decode(bdata)
            if return_str:
                return r.decode()
            return r
        except:
            return None

    @staticmethod
    def get_md5(data):
        bdata = DataUtils.str2bytes(data) if isinstance(data, str) else data
        m = hashlib.md5()
        m.update(bdata)
        return m.hexdigest()

    @staticmethod
    def zlib_compress(data: bytes):
        try:
            return zlib.compress(data)
        except:
            return None

    @staticmethod
    def zlib_decompress(data: bytes):
        try:
            return zlib.decompress(data)
        except:
            return None

    @staticmethod
    def unpack(data: str):
        data_dict = json.loads(data)
        msg_hash = data_dict.get("id")
        msg_cont = data_dict.get("data")

        cal_hash = DataUtils.get_md5(msg_cont)
        if cal_hash != msg_hash:
            return None

        return json.loads(msg_cont)


class LoggerFactory:
    active_logger = {}

    @staticmethod
    def initialize(model: str, stream: bool = False):
        if model in LoggerFactory.active_logger.keys():
            return LoggerFactory.active_logger.get(model)

        logger = logging.getLogger(model)
        logger.setLevel(level=logging.DEBUG)
        fmt = logging.Formatter(FMT, DATEFMT)

        log_dir = os.path.join(os.getcwd(), "logs")
        os.makedirs(log_dir, exist_ok=True)

        filename = os.path.join(log_dir, model)
        file_handler = TimedRotatingFileHandler(
            filename=filename, when="D", backupCount=0, interval=1, encoding="UTF-8"
        )
        file_handler.suffix = "%Y-%m-%d.log"
        file_handler.setFormatter(fmt)
        file_handler.setLevel(level=logging.DEBUG)
        logger.addHandler(file_handler)

        if stream:
            stream_handler = logging.StreamHandler()
            stream_handler.setLevel(level=logging.DEBUG)
            stream_handler.setFormatter(fmt)
            logger.addHandler(stream_handler)

        LoggerFactory.active_logger[model] = logger

        return logger


class AESUtils:
    KEY = None

    @staticmethod
    def _load():
        AESUtils.KEY = CryptoUtils.get_key(b"IiDf9JhBdpmCpH2SfjluSxNpHI8TYFcg")

    @staticmethod
    def aes_key():
        AESUtils._load()
        k = bytearray(16)
        for i, c in enumerate(AESUtils.KEY):
            k[i % 16] ^= ord(AESUtils.KEY[i])
        return bytes(k)

    @staticmethod
    def aes_value(value):
        pad = 16 - (len(value.encode()) % 16)
        return "%s%s" % (value, chr(pad) * pad)

    @staticmethod
    def decrypt(data):
        AESUtils._load()
        k = AESUtils.aes_key()
        cipher = AES.new(k, AES.MODE_ECB)
        value = cipher.decrypt(data)
        return value[: -(int(value[-1]))].decode()

    @staticmethod
    def encrypt(data):
        AESUtils._load()
        k = AESUtils.aes_key()
        v = AESUtils.aes_value(data)
        cipher = AES.new(k, AES.MODE_ECB)
        return cipher.encrypt(v.encode())


class CryptoUtils:
    LIB = None

    @staticmethod
    def _load():
        if CryptoUtils.LIB:
            return

        lib = "crypto.so" if platform.system().startswith("Linux") else "crypto.dll"
        f = os.path.join(os.path.dirname(__file__), lib)
        if not os.path.exists(f):
            raise FileNotFoundError(f)

        CryptoUtils.LIB = ctypes.CDLL(f)
        CryptoUtils.LIB.init()

    @staticmethod
    def get_key(seed):
        CryptoUtils._load()
        if not seed:
            return None
        try:
            k = ctypes.create_string_buffer(33)
            result = CryptoUtils.LIB.getKey(seed, k)
            return k.value.decode() if result == 0 else None
        except Exception as err:
            return None

    @staticmethod
    def encrypt(data: bytes):
        CryptoUtils._load()
        try:
            return CryptoUtils.LIB.doEncryptBytes(data, len(data))
        except Exception as err:
            return -1

    @staticmethod
    def decrypt(data: bytes):
        CryptoUtils._load()
        try:
            return CryptoUtils.LIB.doEncryptBytes(data, data.__len__())
        except:
            return -1

    @staticmethod
    def encrypt_data(data):
        CryptoUtils._load()
        if isinstance(data, str):
            input_ = data.encode("utf-8")
            length = len(input_)
            output = ctypes.create_string_buffer(int(length * 2 + 1))

            try:
                result = CryptoUtils.LIB.doEncryptString(input_, length, output)
                return output.value.decode("utf-8") if result == 0 else None
            except Exception as ex:
                print(ex)
                return None

        elif isinstance(data, bytes):
            try:
                if CryptoUtils.LIB.doEncryptBytes(data, len(data)) == 0:
                    return data
                return None
            except Exception as ex:
                print(ex)
                return None

        else:
            return None

    @staticmethod
    def decrypt_data(data):
        CryptoUtils._load()
        if isinstance(data, str):
            input_ = data.encode("utf-8")
            length = len(input_)
            output = ctypes.create_string_buffer(int(length / 2))
            try:
                result = CryptoUtils.LIB.doDecryptString(input_, length, output)
                return output.value.decode("utf-8") if result == 0 else None
            except Exception as ex:
                print(ex)
                return None

        elif isinstance(data, bytes):
            try:
                result = CryptoUtils.LIB.doEncryptBytes(data, data.__len__())
                return result
            except Exception as ex:
                print("error: %s" % ex)
                return -1

        return -1
